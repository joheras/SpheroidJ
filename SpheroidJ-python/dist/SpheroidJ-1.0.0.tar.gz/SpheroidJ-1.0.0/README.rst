# SpheroidJ

SpheroidJ is a library for spheroid segmentation.

